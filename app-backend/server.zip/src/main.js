sessionStorage.setItem("FECcounter", 0);
sessionStorage.setItem("FPVcounter", 0);
