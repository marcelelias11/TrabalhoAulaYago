const express = require("express");
const app = express();
const cors = require("cors");
const PORT = 8080;
const compression = require("compression");
const bodyParser = require("body-parser");
const helmet = require("helmet");
const RateLimit = require("express-rate-limit");

/*const mysql = require("mysql");
const connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "admin",
  database: "hunterh",
});*/

app.use(cors());

/*app.use(
  helmet.contentSecurityPolicy({
    directives: {
      "script-src": [
        "'self'",
        "code.jquery.com",
        "cdn.jsdelivr.net",
        "https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.5.3/jspdf.min.js",
        "https://html2canvas.hertzen.com/dist/html2canvas.js",
      ],
    },
  })
);*/

const limiter = RateLimit({
  windowMs: 1 * 30 * 1000,
  max: 20,
});
//app.use(limiter);

app.use(express.json());

app.use(express.static("src"));
app.use(compression());

let content = {
  dados: {
    cadastro: [
      {
        title: "Empresa",
        info: "",
      },
      {
        title: "Razão Social",
        info: "",
      },
      {
        title: "CNPJ",
        info: "",
      },
      {
        title: "CEP",
        info: "",
      },
      {
        title: "Endereço",
        info: "",
      },
      {
        title: "Bairro",
        info: "",
      },
      {
        title: "Cidade",
        info: "",
      },
      {
        title: "Estado",
        info: "",
      },
      {
        title: "E-mail",
        info: "",
      },
      {
        title: "Telefone",
        info: "",
      },
      {
        title: "Responsável legal",
        info: "",
      },
      {
        title: "CPF",
        info: "",
      },
      {
        title: "Cargo",
        info: "",
      },
    ],
    contratos: {
      contrato0: [
        {
          title: "Título da vaga",
          info: "",
        },
        {
          title: "Número de vagas",
          info: "",
        },
        {
          title: "Valor da vaga (Em R$)",
          info: "",
        },
      ],
    },
    imposto: 0,
    formapagamento: "",
    FPVs: {
      FPV0: [
        {
          title: "Data do Requerimento",
          info: "",
        },
        {
          title: "Idade Mínima",
          info: "",
        },
        {
          title: "Idade Máxima",
          info: "",
        },
        {
          title: "Gênero",
          info: "",
        },
        {
          title: "Requisitos do Candidato",
          info: "",
        },
        {
          title: "Região onde deverá residir",
          info: "",
        },
        {
          title: "Escolaridade",
          info: "",
        },
        {
          title: "Descreva o que é desejável no perfil do candidato",
          info: "",
        },
        {
          title: "Salário Fixo",
          info: "",
        },
        {
          title: "Comissões",
          info: "",
        },
        {
          title: "Divulgar valor? (Sim/Não)",
          info: "",
        },
        {
          title: "Faixa salarial",
          info: "",
        },
        {
          title: "Benefícios",
          info: "",
        },
        {
          title: "Descrimine o valor dos benefícios",
          info: "",
        },
        {
          title: "Atribuições da Função",
          info: "",
        },
        {
          title: "Carga horária",
          info: "",
        },
        {
          title: "Tipo de Contratação (CLT/MEI/RPA/Outro)",
          info: "",
        },
        {
          title: "Previsão para contratação",
          info: "",
        },
        {
          title: "Observações finais",
          info: "",
        },
      ],
    },
    FECs: {
      FEC0: [
        {
          titleleft: "Realista",
          titleright: "Otimista",
          valueleft: "",
          valueright: "",
        },
        {
          titleleft: "Habilidade em análise",
          titleright: "Habilidade em comunicação",
          valueleft: "",
          valueright: "",
        },
        {
          titleleft: "Habilidade introspectiva",
          titleright: "Habilidade social",
          valueleft: "",
          valueright: "",
        },
        {
          titleleft: "Sensível",
          titleright: "Motivador",
          valueleft: "",
          valueright: "",
        },
        {
          titleleft: "Reservado",
          titleright: "Comunicador e divulgador",
          valueleft: "",
          valueright: "",
        },
        {
          titleleft: "Atento a detalhes",
          titleright: "Generalista",
          valueleft: "",
          valueright: "",
        },
        {
          titleleft: "Busca exatidão em seu trabalho",
          titleright: "Entusiasta",
          valueleft: "",
          valueright: "",
        },
        {
          titleleft: "Busca decisões mais seguras",
          titleright: "Busca decisões mais rápidas",
          valueleft: "",
          valueright: "",
        },
        {
          titleleft: "Condescendente",
          titleright: "Dominante",
          valueleft: "",
          valueright: "",
        },
        {
          titleleft: "Tem o trabalhar estruturado",
          titleright: "Executa várias coisas ao mesmo tempo",
          valueleft: "",
          valueright: "",
        },
        {
          titleleft: "Gosta de trabalhar com o conhecido",
          titleright: "Gosta de novos empreendimentos",
          valueleft: "",
          valueright: "",
        },
        {
          titleleft: "Se preocupa com a regularidade",
          titleright: "Se preocupa com a praticidade",
          valueleft: "",
          valueright: "",
        },
        {
          titleleft: "Tem estilo consultivo",
          titleright: "Tem o estilo agressivo",
          valueleft: "",
          valueright: "",
        },
        {
          titleleft: "Calmo",
          titleright: "Agitado",
          valueleft: "",
          valueright: "",
        },
        {
          titleleft: "Gosta de rotina",
          titleright: "Não gosta de rotina",
          valueleft: "",
          valueright: "",
        },
        {
          titleleft: "Cauteloso",
          titleright: "Destemido",
          valueleft: "",
          valueright: "",
        },
        {
          titleleft: "Gosta de ambientes calmos",
          titleright: "Gosta de ambientes agitados",
          valueleft: "",
          valueright: "",
        },
        {
          titleleft: "Concentrado",
          titleright: "Dinâmico",
          valueleft: "",
          valueright: "",
        },
        {
          titleleft: "Prefere ser orientado",
          titleright: "Gosta de tomar a frente",
          valueleft: "",
          valueright: "",
        },
        {
          titleleft: "Evita riscos",
          titleright: "Assume riscos",
          valueleft: "",
          valueright: "",
        },
        {
          titleleft: "Introvertido",
          titleright: "Extrovertido",
          valueleft: "",
          valueright: "",
        },
        {
          titleleft: "Mais formal",
          titleright: "Mais informal",
          valueleft: "",
          valueright: "",
        },
        {
          titleleft: "É mais crítico",
          titleright: "Amigável",
          valueleft: "",
          valueright: "",
        },
        {
          titleleft: "Se desenvolve via Trabalho",
          titleright: "Se desenvolve via Relacionamentos",
          valueleft: "",
          valueright: "",
        },
      ],
    },
  },
  assinatura: {
    assinatura: "iVBORw0KGgoAAAANSUhEUgAAAMAAAADACAYAAABS3GwHAAAABGdBTUEAALGPC",
  },
};

/*app.post("/contrato", (req, res) => {
  content.contrato = req.body;
  connection.connect();
  connection.query("SELECT 1 + 1 AS solution", (err, rows, fields) => {
  if (err) throw err;
  console.log("The solution is: ", rows[0].solution);
  });
  connection.end(); 
  res.status(201).send("Página Cadastrada!");
});*/

app.post("/dados", (req, res) => {
  content.dados = req.body;
  res.status(201).send("Página Cadastrada!");
});

app.get("/dados", (req, res) => {
  res.status(201).send(content.dados);
});

app.post("/sign", (req, res) => {
  content.assinatura = req.body;
  res.status(201).send("Assinatura Cadastrada!");
});

app.get("/sign", (req, res) => {
  res.status(201).send(content.assinatura);
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
